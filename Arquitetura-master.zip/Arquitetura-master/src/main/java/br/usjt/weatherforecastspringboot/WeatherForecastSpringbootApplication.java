package br.usjt.weatherforecastspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherForecastSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherForecastSpringbootApplication.class, args);
	}

}