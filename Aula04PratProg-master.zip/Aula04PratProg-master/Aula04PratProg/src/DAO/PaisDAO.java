package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Pais;
public class PaisDAO {
	public int criar(Pais pais) {
		String sqlInsert = "INSERT INTO pais(nome, populacao, area) VALUES (?, ?, ?)";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setString(1, pais.getNome());
			stm.setLong(2, pais.getPopulacao());
			stm.setDouble(3, pais.getArea());
			stm.execute();
			String sqlQuery = "SELECT LAST_INSERT_ID()";
			try (PreparedStatement stm2 = conn.prepareStatement(sqlQuery);
					ResultSet rs = stm2.executeQuery();) {
				if (rs.next()) {
					pais.setId(rs.getInt(1));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pais.getId();
	}

	public void atualizar(Pais pais) {
		String sqlUpdate = "UPDATE pais SET nome=?, populacao=?, area=? WHERE id=?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
			stm.setString(1, pais.getNome());
			stm.setLong(2, pais.getPopulacao());
			stm.setDouble(3, pais.getArea());
			stm.setInt(4, pais.getId());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(int id) {
		String sqlDelete = "DELETE FROM pais WHERE id = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
			stm.setInt(1, id);
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Pais carregar(int id) {
		Pais pais = new Pais();
		pais.setId(id);
		String sqlSelect = "SELECT nome, populacao, area FROM pais WHERE pais.id = ?";
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setInt(1, pais.getId());
			try (ResultSet rs = stm.executeQuery();) {
				if (rs.next()) {
					pais.setNome(rs.getString("nome"));
					pais.setPopulacao(rs.getLong("populacao"));
					pais.setArea(rs.getDouble("area"));
				} else {
					pais.setId(-1);
					pais.setNome(null);
					pais.setPopulacao(0);
					pais.setArea(0.00);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return pais;
	}
	public void maiorPopulacao(Pais pais) {
		String sqlMaxPop = "SELECT * FROM pais WHERE populacao = (SELECT max(populacao) FROM Pais)";
		try (Connection conn = ConnectionFactory.obtemConexao()){
			PreparedStatement stm = conn.prepareStatement(sqlMaxPop);
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				pais.setId(rs.getInt("id"));
				pais.setNome(rs.getString("nome"));
				pais.setPopulacao(rs.getLong("populacao"));
				pais.setArea(rs.getDouble("area"));
			}else {
				System.out.println("erro");
			}
			}catch (SQLException e) {
				System.out.println(e);
			}
	}
	public void menorArea(Pais pais) {
		String sqlMinArea = "SELECT * FROM pais WHERE area = (SELECT min(area) FROM pais)";
		try (Connection conn = ConnectionFactory.obtemConexao()){
			PreparedStatement stm = conn.prepareStatement(sqlMinArea);
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				pais.setId(rs.getInt("id"));
				pais.setNome(rs.getString("nome"));
				pais.setPopulacao(rs.getLong("populacao"));
				pais.setArea(rs.getDouble("area"));
			}
			}catch (SQLException e) {
				System.out.println(e);
			}
	}
	public String[] vetorTresPaises() {
		String sqlVetTresPais = "SELECT nome FROM pais ORDER BY id";
		String[] vetorTresPais = new String[3];
		int contador = 0 ;
		try (Connection conn = ConnectionFactory.obtemConexao()){
			PreparedStatement stm = conn.prepareStatement(sqlVetTresPais);
			ResultSet rs = stm.executeQuery();
			while(rs.next() && contador < 3 ) {
				vetorTresPais[contador] = rs.getString("nome");
				contador = contador + 1;
			}
		}catch (SQLException e) {
			System.out.println(e);
		}
		return vetorTresPais;
	}
}