package usjt_ccp3anmca_observer;

public class Teste {
	public static void main(String[] args) {
		WheatherData estacaoMonitoramento = new WheatherData();
		CurrentConditionsDisplay d1 = new CurrentConditionsDisplay();
		StatsDisplay d2 = new StatsDisplay();
		ForecastDisplay d3 = new ForecastDisplay();
		HeatIndexDisplay d4 = new HeatIndexDisplay();
		estacaoMonitoramento.registerObserver(d1);
		estacaoMonitoramento.registerObserver(d2);
		estacaoMonitoramento.registerObserver(d3);
		estacaoMonitoramento.registerObserver(d4);
		estacaoMonitoramento.iniciar();
		
	}
}
