package usjt_ccp3anmca_observer;

public interface Observer {
	public void update (double temperature, double humidity, double pressure);
}
