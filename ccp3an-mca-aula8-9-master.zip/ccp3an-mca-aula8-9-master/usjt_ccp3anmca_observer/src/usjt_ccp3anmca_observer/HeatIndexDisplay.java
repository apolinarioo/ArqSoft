package usjt_ccp3anmca_observer;

public class HeatIndexDisplay extends Display{
	
	private double c1 = -8.78469475556;
	private double c2 = 1.61139411;
	private double c3 = 2.33854883889;
	private double c4 = -0.14611605;
	private double c5 = -0.012308094;
	private double c6 = -0.0164248277778;
	private double c7 = 0.002211732;
	private double c8 = 0.00072546;
	private double c9 = -0.000003582;

	@Override
	public void update(double temperature, double humidity, double pressure) {
		double indiceCalor = (c1 + (c2 * temperature) + (c3 * humidity) + (c4 * temperature * humidity)
				+ (c5 * temperature * temperature) + (c6 * humidity * humidity) + (c7 * temperature * temperature * humidity)
				+ (c8 * temperature * humidity * humidity) + (c9 * temperature * temperature * humidity * humidity));
		System.out.printf("----- Indice de Calor ----\n");	
		System.out.printf("Indice Calor: %.2f\n", indiceCalor);
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

}
