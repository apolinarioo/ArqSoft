package exercicio01;

public class Incremental {
	private static Incremental incremental = null;
	
	private int numero;
	private static int count = 0;
	
	private Incremental() {
	}
	
	public void add() {
		numero = ++count;
	}
	
	public static synchronized Incremental getInstance() {
		if (incremental == null) {
			incremental = new Incremental();
		}
		return incremental;
	}

	public String toString() {
		return "Incremental " + numero;
	}
}
