package exercicio01;

public class TesteIncremental {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			Incremental inc = Incremental.getInstance();
			inc.add();
			System.out.println(inc);
		}
	}
}
