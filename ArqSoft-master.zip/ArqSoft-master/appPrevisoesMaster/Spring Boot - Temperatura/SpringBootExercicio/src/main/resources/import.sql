insert into temperatura (id, dia_Da_Semana, temperatura_Minima, temperatura_Maxima, humidade_Ar, descricao) values (1, 'Segunda', 26, 38, 86, 'Muito quenteeeeee');						
insert into temperatura (id, dia_Da_Semana, temperatura_Minima, temperatura_Maxima, humidade_Ar, descricao) values (2, 'Terca', 26, 38, 86, 'Muito quenteeeeee');						
insert into temperatura (id, dia_Da_Semana, temperatura_Minima, temperatura_Maxima, humidade_Ar, descricao) values (3, 'Quarta', 26, 38, 86, 'Muito quenteeeeee');						
