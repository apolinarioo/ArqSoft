package model;

public abstract class IModel {

	int contador;
	
	public abstract int decrementar();
	public abstract int incrementar();
	
	
}
