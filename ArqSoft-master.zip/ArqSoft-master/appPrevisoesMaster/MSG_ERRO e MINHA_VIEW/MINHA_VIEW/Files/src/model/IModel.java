package model;

public abstract class IModel {

	public int contadorDeMana;
	
	public abstract int castarMagia();
	public abstract int checarMana();
	public abstract int beberPocaoDeMana();
	
	
}
