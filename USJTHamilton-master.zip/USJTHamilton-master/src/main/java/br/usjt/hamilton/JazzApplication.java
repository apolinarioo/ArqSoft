package br.usjt.hamilton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JazzApplication {

	public static void main(String[] args) {
		SpringApplication.run(JazzApplication.class, args);
	}

}